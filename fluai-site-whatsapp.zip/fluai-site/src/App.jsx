
export default function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-100 to-purple-200 text-center p-6">
      <h1 className="text-4xl font-bold mb-4">FluAi</h1>
      <p className="text-lg mb-6">Fale fluentemente com a ajuda da inteligência artificial</p>
      <a href="https://wa.me/5527XXXXXXXXX" target="_blank" className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-full transition duration-300">
        Fale com a FluAi no WhatsApp
      </a>
    </div>
  )
}
